import pandas as pd
import streamlit as st
import pyodbc
from itertools import count
from flask import render_template, redirect, request
import json
import plotly
import plotly.express as px
from statsmodels.tsa.stattools import adfuller
from pmdarima import auto_arima
from statsmodels.tsa.arima_model import ARIMA
import statsmodels.api as sm
import datetime
import numpy as np
from asyncio.windows_events import NULL
from operator import index
import joblib
from sklearn.preprocessing import MinMaxScaler
from PIL import Image
def connection():
    conn = pyodbc.connect(
    "Driver={SQL Server Native Client 11.0};"
    "Server=DESKTOP-A1GH8MG\AJAY;"
    "Database=logins;"
    "Trusted_Connection=yes;"
    )
    return conn
def view_user(username,password):
    lists=[]
    conn=connection() 
    cursor=conn.cursor()
    cursor.execute('SELECT * FROM details WHERE username =? AND passwords = ?',(username,password) )
    row = cursor.fetchall()
    return row

def user_login(username,password):
    conn=connection()
    cursor=conn.cursor()
    cursor.execute('SELECT * FROM details WHERE username =? AND passwords = ?',(username,password))
    data = cursor.fetchall()
    return data

    

def add_user(new_user,new_pass):
    conn=connection() 
    cursor=conn.cursor()
    cursor.execute('SELECT * FROM  details WHERE username =? AND passwords = ?',(new_user,new_pass))
    data = cursor.fetchall()
    if data:
        st.warning("the name and password is already exists")
    else:
        cursor.execute('insert into details(username,passwords) VALUES (?,?)',(new_user,new_pass))
        conn.commit()
        st.success("You have successfully created a valid Account")
        st.info("Go to Login Menu to login")
        st.balloons()
image = Image.open('C:/Users/ajayv/tvs-logo-300x150.png')

st.image(image)
st.title("TVS Sensing Solution")


menu = ["Home","Login","SignUp"]
choice = st.sidebar.selectbox("Menu",menu)
if choice == "Home":
	st.subheader("Home")
elif choice == "Login":
    st.subheader("Login Section")

    username = st.sidebar.text_input("User Name")
    password = st.sidebar.text_input("Password",type='password')
    if st.sidebar.checkbox("Login"):
        #create_usertable()
        correct =  user_login(username,password)   
        
        if correct:
            
            st.success("Logged In as {}".format(username))
            
            task = st.selectbox("Task",["---none---","Machine Production","Machine Fault Detection","Rejection Details","Profiles"])
            if task == "---none---":
                st.write("select the option")
            if task == "Machine Production":
                st.subheader("Machine Production")
                my_form = st.form(key = "form1")
                form_mac = my_form.selectbox('select the machine name',('Machine 1', 'Machine 2', 'Machine 3'))

                form_date = my_form.date_input(
                    "select the date ",datetime.date(2022,8,2))
                form_shift = my_form.selectbox('select the shift',('shift 1', 'shift 2', 'shift 3'))
                #submit = my_form.form_submit_button(label = "Submit")
                if form_shift == 'shift 1':
                    form_shift = '00:00:00'
                elif form_shift == 'shift 2':
                    form_shift = '08:00:00'
                elif form_shift == 'shift 3':
                    form_shift = '16:00:00'
                if my_form.form_submit_button('submit'):
                    dateparse = lambda dates: pd.datetime.strptime(dates, '%Y-%m-%d %H:%M:%S')
                    df = pd.read_csv(r'D:/intern work/.vscode/application/static/machine_changes.csv', parse_dates=['ts'], index_col='ts',date_parser=dateparse)
                    if form_mac == 'Machine 1':
                        machine1=df[df['machines']=='machine1']
                        data2 = machine1.resample('8H').sum()
                        #st.bar_chart(data2)
                        def ad_test(dataset):
                            #series = np.random.randn(100)
                            dftest=adfuller(dataset, autolag= 'AIC')
                            print("1. adf : ",dftest[0])
                            print("2. p-value : ",dftest[1])
                            print("3. no.of,lags : ",dftest[2])
                            print("4. no fo observation used for ADF regression and critical calculation : ",dftest[3])
                            for key, val in dftest[4].items():
                                print("\t",key,":" ,val)
                        ad_test(data2['prod'])
                        stepwise_fit= auto_arima(data2['prod'], trace=True,suppress_warnings=True)
                        train = data2.iloc[:-100]
                        test = data2.iloc[-100:]
                        model = sm.tsa.arima.ARIMA(train['prod'], order=(3,1,3))
                        model=model.fit()
                        start=len(train)
                        end=len(train)+len(test)-1
                        pred=model.predict(start=start,end=end,typ='levels').rename('ARIMA Predictions')
                        pred.index = data2.index[start:end+1]
                        f=pred.astype(int)
                        model2 = sm.tsa.arima.ARIMA(data2['prod'], order=(3,1,3))
                        model2=model2.fit()
                        d = form_date.strftime("%Y"+"-"+"%m"+"-"+"%d")
                        print(d+' '+form_shift)
                        index_future_dates = pd.date_range(start='2022-08-01 00:00:00', end= d+' '+form_shift , freq='8H' )
                        s1 = '2022-08-01 00:00:00' 
                        s2 = d+' '+form_shift 
                        print(s2)              
                        FMT = '%Y-%m-%d %H:%M:%S'
                        t1 = datetime.datetime.strptime(s1, FMT)
                        t2= datetime.datetime.strptime(s2, FMT)
                        diff = t2 - t1
                        day = diff.total_seconds()// (24 * 3600)
                        n=int(day)*3
                        date1,time1 = s1.split()
                        if time1==form_shift:
                            pred = model2.predict(start=len(data2),end=len(data2)+n,typ='levels').rename('ARIMA prediction')
                            f=pred.astype(int)
                        if form_shift == '08:00:00':
                            pred = model2.predict(start=len(data2),end=len(data2)+n+1,typ='levels').rename('ARIMA prediction')
                            f=pred.astype(int)
                        if form_shift == '16:00:00':
                            pred = model2.predict(start=len(data2),end=len(data2)+n+2,typ='levels').rename('ARIMA prediction')
                            f=pred.astype(int)        
                        f.index = index_future_dates
                        st.bar_chart(f)
                    if form_mac == 'Machine 3':
                        machine3=df[df['machines']=='machine3']
                        print(machine3)
                        data4 = machine3.resample('8H').sum()
                        #st.bar_chart(data4)
                    
                        def ad_test(dataset):
                            series = np.random.randn(100)
                            dftest=adfuller(series, autolag= 'AIC')
                            print("1. adf : ",dftest[0])
                            print("2. p-value : ",dftest[1])
                            print("3. no.of,lags : ",dftest[2])
                            print("4. no fo observation used for ADF regression and critical calculation : ",dftest[3])
                            for key, val in dftest[4].items():
                                print("\t",key,":" ,val)
                        ad_test(data4['prod'])
                        stepwise_fit= auto_arima(data4['prod'], trace=True,suppress_warnings=True)
                        train = data4.iloc[:-100]
                        test = data4.iloc[-100:]
                        model = sm.tsa.arima.ARIMA(train['prod'], order=(5,1,3))
                        model=model.fit()
                        start=len(train)
                        end=len(train)+len(test)-1
                        pred=model.predict(start=start,end=end,typ='levels').rename('ARIMA Predictions')
                        pred.index = data4.index[start:end+1]
                        f=pred.astype(int)
                        model2 = sm.tsa.arima.ARIMA(data4['prod'], order=(5,1,3))
                        model2=model2.fit()
                        d = form_date.strftime("%Y"+"-"+"%m"+"-"+"%d")
                        index_future_dates = pd.date_range(start='2022-08-01 00:00:00', end= d+' '+form_shift , freq='8H' )
                        s1 = '2022-08-01 00:00:00'                
                        s2= d+' '+form_shift
                        FMT = '%Y-%m-%d %H:%M:%S'
                        t1 = datetime.datetime.strptime(s1, FMT)
                        t2= datetime.datetime.strptime(s2, FMT)
                        diff = t2 - t1
                        day = diff.total_seconds()// (24 * 3600)
                        n=int(day)*3
                        date1,time1 = s1.split()
                        if time1==form_shift:
                            pred = model2.predict(start=len(data4),end=len(data4)+n,typ='levels').rename('ARIMA prediction')
                            f=pred.astype(int)
                        if form_shift=='08:00:00':
                            pred = model2.predict(start=len(data4),end=len(data4)+n+1,typ='levels').rename('ARIMA prediction')
                            f=pred.astype(int)
                        if form_shift=='16:00:00':
                            pred = model2.predict(start=len(data4),end=len(data4)+n+2,typ='levels').rename('ARIMA prediction')
                            f=pred.astype(int)        
                        f.index = index_future_dates
                        st.bar_chart(f)
                        
                    if form_mac == 'Machine 2':
                        machine2=df[df['machines']=='machine2']
                        data3 = machine2.resample('8H').sum()
                        #st.bar_chart(data3)
                        def ad_test(dataset):
                            #series = np.random.randn(100)
                            dftest=adfuller(dataset, autolag= 'AIC')
                            print("1. adf : ",dftest[0])
                            print("2. p-value : ",dftest[1])
                            print("3. no.of,lags : ",dftest[2])
                            print("4. no fo observation used for ADF regression and critical calculation : ",dftest[3])
                            for key, val in dftest[4].items():
                                print("\t",key,":" ,val)
                        ad_test(data3['prod'])
                        stepwise_fit= auto_arima(data3['prod'], trace=True,suppress_warnings=True)
                        train = data3.iloc[:-85]
                        test = data3.iloc[-85:]
                        model = sm.tsa.arima.ARIMA(train['prod'], order=(5,1,3))
                        model=model.fit()
                        start=len(train)
                        end=len(train)+len(test)-1
                        pred=model.predict(start=start,end=end,typ='levels').rename('ARIMA Predictions')
                        pred.index = data3.index[start:end+1]
                        f=pred.astype(int)
                        model2 = sm.tsa.arima.ARIMA(data3['prod'], order=(5,1,3))
                        model2=model2.fit()
                        d = form_date.strftime("%Y"+"-"+"%m"+"-"+"%d")
                        index_future_dates = pd.date_range(start='2022-08-01 00:00:00', end= d+' '+form_shift , freq='8H' )
                        s1 = '2022-08-01 00:00:00'                
                        s2= d+' '+form_shift
                        FMT = '%Y-%m-%d %H:%M:%S'
                        t1 = datetime.datetime.strptime(s1, FMT)
                        t2= datetime.datetime.strptime(s2, FMT)
                        diff = t2 - t1
                        day = diff.total_seconds()// (24 * 3600)
                        n=int(day)*3
                        date1,time1 = s1.split()
                        if form_shift==time1:
                            pred = model2.predict(start=len(data3),end=len(data3)+n,typ='levels').rename('ARIMA prediction')
                            f=pred.astype(int)
                        if form_shift=='08:00:00':
                            pred = model2.predict(start=len(data3),end=len(data3)+n+1,typ='levels').rename('ARIMA prediction')
                            f=pred.astype(int)
                        if form_shift=='16:00:00':
                            pred = model2.predict(start=len(data3),end=len(data3)+n+2,typ='levels').rename('ARIMA prediction')
                            f=pred.astype(int)        
                        f.index = index_future_dates
                        st.bar_chart(f)
                else:
                    st.write('')

            elif task == "Machine Fault Detection":
                st.subheader("Machine Fault Detection")
                np.warnings.filterwarnings('ignore', category=np.VisibleDeprecationWarning) 

                #importing the model
                model = joblib.load('./MM.sav')

                #read data from original csv file
                dupli_data=  pd.read_csv(r'C:/Users/ajayv/predictive_maintenance.csv')

                dupli_data = dupli_data.drop(['UDI','Product ID','Failure Type'],axis =1)

                #preprocess the numerical data and categorical data

                def pre_processing(df):

                    #numerical data
                    num=['Air temperature [K]','Process temperature [K]','Rotational speed [rpm]','Torque [Nm]','Tool wear [min]']

                    for i in num:
                        row =[]
                        for j in dupli_data[i]:
                            row.append([j])

                        row.append([df[i]])
                        
                        tenure = np.array(row)
                        sc = MinMaxScaler()
                        tenure=sc.fit_transform(tenure)
                        
                        df[i]=tenure[len(tenure)-1]


                    return df


                air_temp = st.number_input('AIR TEMPERATURE (K):',0.0,10000.0)
                process_temp = st.number_input('PROCESS TEMPERATURE (K):',0.0,10000.0)
                rotational_speed = st.number_input('ROTATIONAL SPEED (rpm):',0.0,10000.0)
                torque = st.number_input('TORQUE (Nm):',0.0,10000.0)
                tool_wear = st.number_input('TOOL WEAR (min) :',0.0,10000.0)

                preddata={
                'Air temperature [K]': air_temp,
                'Process temperature [K]': process_temp,
                'Rotational speed [rpm]': rotational_speed,
                'Torque [Nm]': torque,
                'Tool wear [min]': tool_wear
                }

                st.write('Overview of the data that entered : ')
                df = pd.DataFrame.from_dict([preddata])
                st.dataframe(df)

                #Prediction
                if st.button('Predict'):
                    if(model.predict(pre_processing(df))[0]==1):
                        st.warning('Failure')
                    else:
                        st.success('No Failure')
                        st.balloons()
            elif task == "Rejection Details":
                st.subheader("Rejection Details")
                my_form = st.form(key = "form1")
                form_mac = my_form.selectbox('select the machine name',('Machine 1', 'Machine 2', 'Machine 3'))
                if my_form.form_submit_button('submit'):
                    dateparse = lambda dates: pd.datetime.strptime(dates, '%Y-%m-%d %H:%M:%S')
                    df2 = pd.read_csv(r'C:/Users/ajayv/combined.csv', parse_dates=['ts'], index_col='ts',date_parser=dateparse)
                    df2=df2.drop(['active','RejectionNo','item','oper_num','nw_old'],axis=1)
                    if form_mac == 'Machine 1':
                        machine1=df2[df2['mac_id']==1]
                        machine1 = machine1.astype({'mac_id':'int'})
                        p=machine1['Rejection'].value_counts()
                        df_result = pd.DataFrame(p)
                        df_result = df_result.reset_index()
                        df_result.columns = ['Reasons', 'Total']
                        df_result.loc[4:, 'Reasons'] = 'other'
                        fig1 =px.pie(df_result,values='Total',names='Reasons',color_discrete_sequence=px.colors.sequential.RdBu)  
                        st.header("most no of rejection reason for machine 1")
                        st.plotly_chart(fig1)
                        dtf = pd.DataFrame(columns=['Rejaction_name','Count'])
                        for i in machine1['Rejection'].unique():
                            rej = machine1[machine1['Rejection']==i]['rejection'].values
                            summ =np.sum(rej)
                            dtf.loc[len(dtf.index)]=(i,summ)
                        fig2= px.bar(dtf,x='Rejaction_name',y='Count', color="Rejaction_name", hover_name="Rejaction_name",
                                    color_discrete_sequence=["red", "green", "blue", "goldenrod"])
                        st.plotly_chart(fig2)
                        machine1=machine1.drop(['session_id','reason_code','Rejection','mac_id'],axis=1)
                        data= machine1.resample('D').sum()
                        data.drop(data.index[data['rejection'] == 0], inplace = True)
                        st.header("total no rejection for one day")
                        st.bar_chart(data)
                    if form_mac == 'Machine 2':
                        machine2=df2[df2['mac_id']==5]
                        machine2 = machine2.astype({'mac_id':'int'})
                        p=machine2['Rejection'].value_counts()
                        df_result = pd.DataFrame(p)
                        df_result = df_result.reset_index()
                        df_result.columns = ['Reasons', 'Total']
                        df_result.loc[5:, 'Reasons'] = 'other'
                        fig1 = px.pie(df_result,values='Total',names='Reasons',color_discrete_sequence=px.colors.sequential.RdBu,title="most no of rejection reason for machine 2")
                        st.header("most no of rejection reason for machine 2")
                        st.plotly_chart(fig1)
                        dtf = pd.DataFrame(columns=['Rejaction_name','Count'])
                        for i in machine2['Rejection'].unique():
                            rej = machine2[machine2['Rejection']==i]['rejection'].values
                            summ =np.sum(rej)
                            dtf.loc[len(dtf.index)]=(i,summ)
                        fig2 = px.bar(dtf,x='Rejaction_name',y='Count', color="Rejaction_name", hover_name="Rejaction_name",
                                color_discrete_sequence=["red", "green", "blue", "goldenrod", "magenta"])
                        st.header("Amount of product rejected for the Reasons")
                        st.plotly_chart(fig2)
                        machine2=machine2.drop(['session_id','reason_code','Rejection','mac_id'],axis=1)
                        data1= machine2.resample('D').sum()
                        data1.drop(data1.index[data1['rejection'] == 0], inplace = True)
                        c=data1[:50]
                        st.header("total no rejection for one day")
                        st.bar_chart(data1)
                    if form_mac == 'Machine 3':
                        machine3=df2[df2['mac_id']==13]
                        machine3 = machine3.astype({'mac_id':'int'})
                        p=machine3['Rejection'].value_counts()
                        df_result = pd.DataFrame(p)
                        df_result = df_result.reset_index()
                        df_result.columns = ['Reasons', 'Total']
                        df_result.loc[5:, 'Reasons'] = 'other'
                        fig1 = px.pie(df_result,values='Total',names='Reasons',color_discrete_sequence=px.colors.sequential.RdBu)
                        st.header("most no of rejection reason for machine 3")
                        st.plotly_chart(fig1)
                        dtf = pd.DataFrame(columns=['Rejaction_name','Count'])
                        for i in machine3['Rejection'].unique():
                            rej = machine3[machine3['Rejection']==i]['rejection'].values
                            summ =np.sum(rej)
                            dtf.loc[len(dtf.index)]=(i,summ)
                        fig2 = px.bar(dtf,x='Rejaction_name',y='Count', color="Rejaction_name", hover_name="Rejaction_name",
                                    color_discrete_sequence=["red", "green", "blue", "goldenrod", "magenta"])
                        st.header("Amount of product rejected for the Reasons")
                        st.plotly_chart(fig2)
                        machine3=machine3.drop(['session_id','reason_code','Rejection','mac_id'],axis=1)
                        data2= machine3.resample('D').sum()
                        data2.drop(data2.index[data2['rejection'] == 0], inplace = True)
                        st.header("total no rejection for one day")
                        st.bar_chart(data2)

            elif task == "Profiles":
                st.subheader("User Profiles")
                user_result = view_user(username,password)
                clean_db = pd.DataFrame(user_result,columns=["My Account"])
                test=clean_db.astype(str)
                st.dataframe(test)
        else:
            st.warning("Incorrect Username/Password")
                    
elif choice == "SignUp":
    st.header("Create New Account")
    new_user = st.text_input("Username")
    new_pass = st.text_input("Password",type='password')
    st.button ("create", on_click=add_user, args= (new_user, new_pass))


    
    


